package com.example.myapplication3.classes

import android.annotation.SuppressLint
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.myapplication3.R

class ChatAdapter(val context: Context, val ll: ArrayList<MsgClass>) :

    RecyclerView.Adapter<ChatAdapter.viewHolder>() {

    private val currentUEmail = Constants(context).auth.currentUser!!.email

    val msgLeft = 0
    val megRight = 1
    var isRight = false

    class viewHolder(I: View) : RecyclerView.ViewHolder(I)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): viewHolder {
        return if (viewType == msgLeft) {
            viewHolder(
                LayoutInflater.from(context).inflate(R.layout.left_chat, parent, false)
            )
        } else {
            viewHolder(
                LayoutInflater.from(context).inflate(R.layout.right_chat, parent, false)
            )
        }
    }

    @SuppressLint("SetTextI18n")
    override fun onBindViewHolder(holder: viewHolder, position: Int) {

        val rightMsg: TextView = holder.itemView.findViewById(R.id.rightMsg)
        val leftMsg: TextView = holder.itemView.findViewById(R.id.leftMsg)

        if (isRight) {
            rightMsg.text = ll[position].message
        } else {
            leftMsg.text = ll[position].message
        }
    }

    override fun getItemCount(): Int {
        return ll.size
    }

    override fun getItemViewType(position: Int): Int {

        return if (ll[position].sender == currentUEmail) {
            isRight = true
            megRight
        } else {
            isRight = false
            msgLeft
        }
    }

}
