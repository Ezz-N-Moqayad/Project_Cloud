package com.example.myapplication3.modle

class Course(
    var id_Course: String = "",
    var Name_Course: String = "",
    var Number_Course: String = "",
    var id_Lecturer: String = "",
    var Lecturer: String = ""
)

