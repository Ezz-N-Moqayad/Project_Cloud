package com.example.myapplication3.navBottom.messengerScreen

import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.myapplication3.R
import com.example.myapplication3.logIn.MainActivity
import com.example.myapplication3.modle.Course
import com.example.myapplication3.modle.Lecturer
import com.example.myapplication3.modle.Student
import com.example.myapplication3.navBottom.homeScreen.course.CoursePageLecturer
import com.example.myapplication3.navBottom.homeScreen.course.ViewHolder
import com.firebase.ui.database.FirebaseRecyclerAdapter
import com.firebase.ui.database.FirebaseRecyclerOptions
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.ktx.database
import com.google.firebase.ktx.Firebase

class Messenger : Fragment() {

    private lateinit var rvLecturer: RecyclerView
    private lateinit var rvStudent: RecyclerView

    var auth: FirebaseAuth = Firebase.auth
    var database: DatabaseReference = Firebase.database.reference
    lateinit var adapterLecturer: FirebaseRecyclerAdapter<Lecturer, ViewHolder.ViewHolderLecturer>
    lateinit var adapterStudent: FirebaseRecyclerAdapter<Student, ViewHolder.ViewHolderLecturer>

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_messenger, container, false)

        rvLecturer = view.findViewById(R.id.rvLecturer)
        rvLecturer.layoutManager = LinearLayoutManager(context)
        rvStudent = view.findViewById(R.id.rvStudent)
        rvStudent.layoutManager = LinearLayoutManager(context)

        getAllLecturer(rvLecturer)

        var id_Lecturer = ""
        database.child("Lecturer").get().addOnSuccessListener { dataSnapshot ->
            for (document in dataSnapshot.children) {
                if (document.child("Email").value.toString() == auth.currentUser!!.email) {
                    id_Lecturer = document.child("id_Lecturer").value.toString()
                    getAllStudent(rvStudent, id_Lecturer)
                }
            }
        }

        return view
    }

    private fun getAllLecturer(rvLecturer: RecyclerView) {

        val query = database.child("Lecturer")
        val options =
            FirebaseRecyclerOptions.Builder<Lecturer>().setQuery(query, Lecturer::class.java)
                .build()
        adapterLecturer = object :
            FirebaseRecyclerAdapter<Lecturer, ViewHolder.ViewHolderLecturer>(options) {
            override fun onCreateViewHolder(
                parent: ViewGroup,
                viewType: Int
            ): ViewHolder.ViewHolderLecturer {
                val root = LayoutInflater.from(context)
                    .inflate(R.layout.lucturer_item, parent, false)
                return ViewHolder.ViewHolderLecturer(root)
            }

            override fun onBindViewHolder(
                holder: ViewHolder.ViewHolderLecturer,
                position: Int,
                model: Lecturer
            ) {
                holder.name_lecturer.text = model.First_Name
                holder.name2_lecturer.text = model.Middle_Name
                holder.name3_lecturer.text = model.Family_Name
                holder.id_person.setOnClickListener {
                    //      startActivity(Intent(context, ChattingActivity::class.java))
                }
            }
        }
        adapterLecturer.startListening()
        rvLecturer.adapter = adapterLecturer
    }

    private fun getAllStudent(rvStudent: RecyclerView, id_Lecturer: String) {

        val query = database.child("Lecturer/$id_Lecturer/Student")
        val options =
            FirebaseRecyclerOptions.Builder<Student>().setQuery(query, Student::class.java)
                .build()
        adapterStudent = object :
            FirebaseRecyclerAdapter<Student, ViewHolder.ViewHolderLecturer>(options) {
            override fun onCreateViewHolder(
                parent: ViewGroup,
                viewType: Int
            ): ViewHolder.ViewHolderLecturer {
                val root = LayoutInflater.from(context)
                    .inflate(R.layout.lucturer_item, parent, false)
                return ViewHolder.ViewHolderLecturer(root)
            }

            override fun onBindViewHolder(
                holder: ViewHolder.ViewHolderLecturer,
                position: Int,
                model: Student
            ) {
                holder.name_lecturer.text = model.First_Name
                holder.name2_lecturer.text = model.Middle_Name
                holder.name3_lecturer.text = model.Family_Name
                holder.id_person.setOnClickListener {
                    // startActivity(Intent(context, ChattingActivity::class.java))
                }
            }
        }
        adapterStudent.startListening()
        rvStudent.adapter = adapterStudent
    }
}
