package com.example.myapplication3.modle

class AssignmentCourse(
    var id_Assignment: String = "",
    var Name_Assignment: String = "",
    var Required_Assignment: String = "",
    var Number_Course: String = "",
    var idLecturer: String = ""
)