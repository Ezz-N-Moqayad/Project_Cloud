package com.example.myapplication3.classes

data class VideoData(
    var VideoId: String = "",
    var VideoName: String = "",
    var VideoDesc: String = "",
    var VideoNumber: Long = 0,
    var VideoUrl: String = "",
    var VideoImage: String = "",
    var VideoFile: String = ""
)