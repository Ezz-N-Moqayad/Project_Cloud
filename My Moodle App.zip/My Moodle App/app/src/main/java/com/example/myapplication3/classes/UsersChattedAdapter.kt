package com.example.myapplication3.classes

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import coil.load
import com.example.myapplication3.navBottom.messengerScreen.ChattingActivity
import com.example.myapplication3.R

class UsersChattedAdapter(var cont: Context, var arr: ArrayList<Uuser>) :
    RecyclerView.Adapter<UsersChattedAdapter.viewHolder>() {

    class viewHolder(v: View) : RecyclerView.ViewHolder(v)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): viewHolder {
        return viewHolder(
            LayoutInflater.from(cont).inflate(R.layout.course_users_template, parent, false)
        )
    }

    override fun onBindViewHolder(holder: viewHolder, position: Int) {

        val U_Image: ImageView = holder.itemView.findViewById(R.id.U_Image)
        val U_Name: TextView = holder.itemView.findViewById(R.id.U_Name)
        U_Name.text = arr[position].name
        if (arr[position].image.isNotEmpty()) {
            U_Image.load(arr[position].image)
        }

        holder.itemView.setOnClickListener {
            val i = Intent(cont, ChattingActivity::class.java)
            i.putExtra("ReceiverEmail", arr[position].email)
            cont.startActivity(i)
        }
    }

    override fun getItemCount(): Int {
        return arr.size
    }
}