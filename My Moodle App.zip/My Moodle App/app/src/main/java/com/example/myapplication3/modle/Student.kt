package com.example.myapplication3.modle

class Student(
    var id_Student: String = "",
    var First_Name: String = "",
    var Middle_Name: String = "",
    var Family_Name: String = "",
    var Birth_Date: String = "",
    var Address: String = "",
    var Email: String = "",
    var Mobile: String = "",
    var Category: String = "",
    var Password: String = ""
)