package com.example.myapplication3.modle

class FileCourse(
    var id_File: String = "",
    var Name_File: String = "",
    var Uri_File: String = "",
    var Number_Course: String = "",
    var idLecturer: String = ""
)