package com.example.myapplication3.modle

class VideoCourse(
    var id_Video: String = "",
    var Name_Video: String = "",
    var Uri_Video: String = "",
    var Number_Course: String = "",
    var idLecturer: String = ""
)