package com.example.myapplication3.classes

data class Uuser(var email: String = "", var image: String = "", var name: String = "")
