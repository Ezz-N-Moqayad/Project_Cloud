package com.example.myapplication3.classes

data class MsgClass(
    var message: String = "",
    var receiver: String = "",
    var sender: String = ""
)